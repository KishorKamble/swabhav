﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_Circle_App
{
 
    class Circle
    {
        private float Radius;
        private string Color;
        public float CalculateArea()
        {
            //return ( 3.14f * Radius * Radius) ; // circle area = pi *r*r

            return (float)Math.Round(3.14f * Radius * Radius, 2, MidpointRounding.AwayFromZero);


        }

        public float Perimeter()            
        {
            //return (2 * 3.14f * Radius); // circle perimeter = 2*pi*r

           return (float)Math.Round(2 * 3.14f * Radius, 2, MidpointRounding.AwayFromZero);
        }


        public void SetRadius(float rad)
        {
            Radius = rad;
        }

        public void SetColor(string clr)
        {
            if (clr =="Red")
            {
                Color = clr;
            }
            else if (clr =="Green")
            {
                Color = clr;
            }
            else if (clr == "Blue")
            {
                Color = clr;
            }
            else
            {
                Color = "Red";
            }
        }

        public float GetRadius()
        {
            return Radius;
        }
        public String  GetColor()
        {
            return Color;
        }
    }
}
